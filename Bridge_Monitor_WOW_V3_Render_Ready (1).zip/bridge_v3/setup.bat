@echo off
cd /d "%~dp0"
if not exist "venv" python -m venv venv
call venv\Scripts\activate.bat
python -m pip install -r requirements.txt
echo.
echo Setup complete. Now double-click "Bridge Monitor.bat".
pause
